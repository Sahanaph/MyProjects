import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.SystemColor;

public class AddQP extends JFrame {

	private JPanel contentPane;
	private JTextField course;
	private JTextField exam;
	private JTextField sem;
	private JTextField sub;
	private JTextField pic;
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddQP frame = new AddQP();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddQP() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 993, 579);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		course = new JTextField();
		course.setFont(new Font("Times New Roman", Font.BOLD, 18));
		course.setBounds(249, 87, 255, 44);
		contentPane.add(course);
		course.setColumns(10);
		
		exam = new JTextField();
		exam.setFont(new Font("Times New Roman", Font.BOLD, 18));
		exam.setColumns(10);
		exam.setBounds(249, 152, 255, 44);
		contentPane.add(exam);
		
		sem = new JTextField();
		sem.setFont(new Font("Times New Roman", Font.BOLD, 18));
		sem.setColumns(10);
		sem.setBounds(249, 219, 255, 44);
		contentPane.add(sem);
		
		sub = new JTextField();
		sub.setFont(new Font("Times New Roman", Font.BOLD, 18));
		sub.setColumns(10);
		sub.setBounds(249, 290, 255, 44);
		contentPane.add(sub);
		
		pic = new JTextField();
		pic.setFont(new Font("Times New Roman", Font.BOLD, 18));
		pic.setColumns(10);
		pic.setBounds(249, 358, 255, 44);
		contentPane.add(pic);
		
		JLabel lblNewLabel = new JLabel("COURSE_CODE");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBounds(44, 93, 153, 34);
		contentPane.add(lblNewLabel);
		
		JLabel lblExamdate = new JLabel("EXAM_DATE");
		lblExamdate.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblExamdate.setBounds(43, 156, 129, 34);
		contentPane.add(lblExamdate);
		
		JLabel lblSemester = new JLabel("SEMESTER");
		lblSemester.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblSemester.setBounds(44, 223, 116, 34);
		contentPane.add(lblSemester);
		
		JLabel lblSubject = new JLabel("COURSE");
		lblSubject.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblSubject.setBounds(44, 294, 116, 34);
		contentPane.add(lblSubject);
		
		JLabel lblPicture = new JLabel("PICTURE");
		lblPicture.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblPicture.setBounds(44, 362, 116, 34);
		contentPane.add(lblPicture);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ONLINEBOOKS","sahana","1405");
					File file=new File("D:\\nature.jpg");
					FileInputStream fis =new FileInputStream(file);
					PreparedStatement ps=conn.prepareStatement("insert into QUESTION_PAPER(Course_code,Exam_Date,semester,subject,picture) values(?,?,?,?,?);"); 
					ps.setString(1, course.getText());
					ps.setString(2, exam.getText());
					ps.setString(3, sem.getText());
					ps.setString(4, sub.getText());
					ps.setBinaryStream(5, fis,(int)file.length());
					int x=ps.executeUpdate();
					if (x>0) {
						System.out.println("Added Successful");
					}
							
					
					} catch(Exception e1) {
					System.out.println(e1);
				}
				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(223, 449, 129, 34);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Option op3= new Option();
				op3.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnNewButton_1.setBounds(737, 449, 116, 34);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SHARATH\\Desktop\\TEXT BOOKS\\New folder\\E-Books-PNG-High-Quality-Image.png"));
		lblNewLabel_1.setBounds(554, 93, 415, 326);
		contentPane.add(lblNewLabel_1);
	}

}
