import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.SystemColor;

public class Addbook extends JFrame {

	private JPanel contentPane;
	private JTextField name;
	private JTextField author;
	private JTextField subject;
	private JTextField semester;
	private JTextField edition;
	private JTextField url;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Addbook frame = new Addbook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Addbook() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1025, 638);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		name = new JTextField();
		name.setFont(new Font("Times New Roman", Font.BOLD, 17));
		name.setBounds(196, 76, 297, 49);
		contentPane.add(name);
		name.setColumns(10);
		
		author = new JTextField();
		author.setFont(new Font("Times New Roman", Font.BOLD, 17));
		author.setColumns(10);
		author.setBounds(196, 219, 297, 49);
		contentPane.add(author);
		
		subject = new JTextField();
		subject.setFont(new Font("Times New Roman", Font.BOLD, 17));
		subject.setColumns(10);
		subject.setBounds(196, 372, 297, 49);
		contentPane.add(subject);
		
		semester = new JTextField();
		semester.setFont(new Font("Times New Roman", Font.BOLD, 17));
		semester.setColumns(10);
		semester.setBounds(196, 293, 297, 49);
		contentPane.add(semester);
		
		edition = new JTextField();
		edition.setFont(new Font("Times New Roman", Font.BOLD, 17));
		edition.setColumns(10);
		edition.setBounds(196, 441, 297, 49);
		contentPane.add(edition);
		
		url = new JTextField();
		url.setFont(new Font("Times New Roman", Font.BOLD, 17));
		url.setColumns(10);
		url.setBounds(196, 149, 297, 49);
		contentPane.add(url);
		
		JLabel lblNewLabel = new JLabel("NAME");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblNewLabel.setBounds(40, 75, 91, 49);
		contentPane.add(lblNewLabel);
		
		JLabel lblAuthor = new JLabel("AUTHOR");
		lblAuthor.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblAuthor.setBounds(40, 218, 135, 49);
		contentPane.add(lblAuthor);
		
		JLabel lblSubject = new JLabel("COURSE");
		lblSubject.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblSubject.setBounds(40, 371, 135, 49);
		contentPane.add(lblSubject);
		
		JLabel lblSemester = new JLabel("SEMESTER");
		lblSemester.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblSemester.setBounds(40, 292, 135, 49);
		contentPane.add(lblSemester);
		
		JLabel lblEdition = new JLabel("EDITION");
		lblEdition.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblEdition.setBounds(40, 440, 135, 49);
		contentPane.add(lblEdition);
		
		JLabel lblUrl = new JLabel("URL");
		lblUrl.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblUrl.setBounds(40, 148, 135, 49);
		contentPane.add(lblUrl);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ONLINEBOOKS","sahana","1405");
					PreparedStatement ps=conn.prepareStatement("insert into BOOK(name,url,author,semester,subject,edition) values(?,?,?,?,?,?);");
					ps.setString(1, name.getText());
					ps.setString(2, url.toString());
					ps.setString(3, author.getText());
					ps.setString(4, semester.getText());
					ps.setString(5, subject.getText());
					ps.setString(6, edition.getText());
					int x=ps.executeUpdate();
					if (x>0) {
						System.out.println("Added Successfully");
					}
					
				} catch(Exception e1) {
					System.out.println(e1);
				}				
			}
		});	
			
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnNewButton.setBounds(208, 530, 129, 31);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Option op2=new Option();
				op2.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnNewButton_1.setBounds(689, 530, 110, 29);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SHARATH\\Desktop\\TEXT BOOKS\\New folder\\Ebooks.png"));
		lblNewLabel_1.setBounds(590, 110, 394, 338);
		contentPane.add(lblNewLabel_1);
		
		
	}
}

