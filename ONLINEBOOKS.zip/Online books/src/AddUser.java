import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.SystemColor;

public class AddUser extends JFrame {

	private JPanel contentPane;
	private JTextField fname;
	private JTextField lname;
	private JTextField id;
	private JTextField sem;
	private JTextField pass;
	private JTextField role;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddUser frame = new AddUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddUser() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 876, 637);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		fname = new JTextField();
		fname.setFont(new Font("Times New Roman", Font.BOLD, 18));
		fname.setBounds(213, 69, 236, 42);
		contentPane.add(fname);
		fname.setColumns(10);
		
		lname = new JTextField();
		lname.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lname.setColumns(10);
		lname.setBounds(213, 136, 236, 42);
		contentPane.add(lname);
		
		id = new JTextField();
		id.setFont(new Font("Times New Roman", Font.BOLD, 18));
		id.setColumns(10);
		id.setBounds(213, 201, 236, 42);
		contentPane.add(id);
		
		sem = new JTextField();
		sem.setFont(new Font("Times New Roman", Font.BOLD, 18));
		sem.setColumns(10);
		sem.setBounds(213, 268, 236, 42);
		contentPane.add(sem);
		
		JLabel lblNewLabel = new JLabel("FNAME");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setBounds(59, 77, 81, 25);
		contentPane.add(lblNewLabel);
		
		JLabel lblLname = new JLabel("LNAME");
		lblLname.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblLname.setBounds(59, 144, 81, 25);
		contentPane.add(lblLname);
		
		JLabel lblId = new JLabel("ID");
		lblId.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblId.setBounds(59, 209, 81, 25);
		contentPane.add(lblId);
		
		JLabel lblSemester = new JLabel("SEMESTER");
		lblSemester.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblSemester.setBounds(59, 272, 113, 33);
		contentPane.add(lblSemester);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ONLINEBOOKS","sahana","1405");
					PreparedStatement ps=conn.prepareStatement("insert into USER(Fname,Lname,ID,semester,password) values(?,?,?,?,?);"); 
					ps.setString(1, fname.getText());
					ps.setString(2, lname.getText());
					ps.setString(3, id.getText());
					ps.setString(4, sem.getText());
					ps.setString(5, pass.getText());
					PreparedStatement pst=conn.prepareStatement("insert into USER_ROLE(user_id,u_role)values(?,?);");
					pst.setString(1, id.getText());
					pst.setString(2, role.getText());
					int x=ps.executeUpdate();
					int x1=pst.executeUpdate();
					if (x>0) {
						System.out.println("Added Successful");
					}
							
					
					} catch(Exception e1) {
					System.out.println(e1);
				}	
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(177, 539, 125, 33);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Option op1=new Option();
				op1.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnNewButton_1.setBounds(679, 541, 113, 29);
		contentPane.add(btnNewButton_1);
		
		pass = new JTextField();
		pass.setFont(new Font("Times New Roman", Font.BOLD, 18));
		pass.setColumns(10);
		pass.setBounds(213, 333, 236, 42);
		contentPane.add(pass);
		
		JLabel lblpass = new JLabel("PASSWORD");
		lblpass.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblpass.setBounds(59, 337, 113, 33);
		contentPane.add(lblpass);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SHARATH\\Desktop\\TEXT BOOKS\\New folder\\unnamed (2).png"));
		lblNewLabel_1.setBounds(539, 107, 313, 300);
		contentPane.add(lblNewLabel_1);
		
		role = new JTextField();
		role.setFont(new Font("Times New Roman", Font.BOLD, 18));
		role.setColumns(10);
		role.setBounds(213, 397, 236, 42);
		contentPane.add(role);
		
		JLabel lblRole = new JLabel("ROLE");
		lblRole.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblRole.setBounds(59, 401, 113, 33);
		contentPane.add(lblRole);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.BOLD, 18));
		textField.setColumns(10);
		textField.setBounds(213, 461, 236, 42);
		contentPane.add(textField);
		
		JLabel lblEmailId = new JLabel("EMAIL ID");
		lblEmailId.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblEmailId.setBounds(59, 461, 113, 33);
		contentPane.add(lblEmailId);
	}
}
