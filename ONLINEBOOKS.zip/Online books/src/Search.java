import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.SystemColor;
import javax.swing.JEditorPane;

public class Search extends JFrame {

	private JPanel contentPane;
	private JTextField course;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JEditorPane editorPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search frame = new Search();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Search() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1028, 659);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		course = new JTextField();
		course.setFont(new Font("Times New Roman", Font.BOLD, 12));
		course.setBounds(196, 297, 636, 37);
		contentPane.add(course);
		course.setColumns(10);
		
		JButton btnNewButton = new JButton("SEARCH");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ONLINEBOOKS","sahana","1405");
					PreparedStatement ps=conn.prepareStatement("Select url from book where subject=?");
					ps.setString(1, course.getText());
					ResultSet rs=ps.executeQuery();
					
					if(rs.next()==false) {
					JOptionPane.showMessageDialog(null,"Sorry Url is not found");
					}else {
					 editorPane.setText(rs.getString("url"));
					}
				}  
		
				
                    catch(Exception e1) {
					System.out.println(e1);
                    }
				}
			}
		);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(440, 361, 139, 33);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User_Options us1=new User_Options();
				us1.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 17));
		btnNewButton_1.setBounds(919, 579, 85, 33);
		contentPane.add(btnNewButton_1);
		
		lblNewLabel = new JLabel("ENTER THE COURSE NAME");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBounds(196, 241, 453, 43);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SHARATH\\Desktop\\TEXT BOOKS\\New folder\\5aa3ae5d9fc609199d0ff24a.png"));
		lblNewLabel_1.setBounds(10, 10, 472, 219);
		contentPane.add(lblNewLabel_1);
		
		editorPane = new JEditorPane();
		editorPane.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		editorPane.setBounds(196, 455, 636, 33);
		contentPane.add(editorPane);
	}
}
