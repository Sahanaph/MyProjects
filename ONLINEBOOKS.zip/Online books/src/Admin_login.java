import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.SystemColor;

public class Admin_login extends JFrame {

	private JPanel contentPane;
	private JTextField id;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_login frame = new Admin_login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_login() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 804, 402);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		id = new JTextField();
		id.setFont(new Font("Times New Roman", Font.BOLD, 17));
		id.setBounds(132, 88, 201, 42);
		contentPane.add(id);
		id.setColumns(10);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ONLINEBOOKS","sahana","1405");
					PreparedStatement ps=conn.prepareStatement("Select * from ADMIN where ID  = ? and PASSWORD = ?");
					ps.setString(1, id.getText());
					ps.setString(2, pass.getText());
					ResultSet rs=ps.executeQuery();
					int count=0;
					while(rs.next()) {
						count=count+1;
					}
					if(count==1) {
				        dispose();
				        Option op = new Option();
						op.setVisible(true);
					}else if(count>1) {
						JOptionPane.showMessageDialog(null,"Duplicate ID and Password");
					}else {
						JOptionPane.showMessageDialog(null,"ID and password is not Correct.Try again..");
					}
					rs.close();
					ps.close();
					
                    } catch(Exception e1) {
					System.out.println(e1);
				}	return;			
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 17));
		btnNewButton.setBounds(172, 274, 97, 30);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("LOGIN_ID");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblNewLabel.setBounds(134, 48, 103, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SHARATH\\Desktop\\TEXT BOOKS\\New folder\\LoginRed.png"));
		lblNewLabel_1.setBounds(418, 23, 310, 298);
		contentPane.add(lblNewLabel_1);
		
		pass = new JPasswordField();
		pass.setBounds(132, 180, 201, 42);
		contentPane.add(pass);
	}
}
